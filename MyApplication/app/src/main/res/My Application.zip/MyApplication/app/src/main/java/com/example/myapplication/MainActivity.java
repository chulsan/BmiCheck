package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        float config = newConfig.fontScale;
        final TextView txtview =findViewById(R.id.title);
        txtview.setTextSize(newConfig.fontScale*100);
        Log.d("test =",""+config);
    }

    public void clickToCalculate(View view){
        final EditText In_height = findViewById(R.id.height);
        final EditText In_weight = findViewById(R.id.weight);
        final TextView BMI_txt = findViewById(R.id.BMI);
        final TextView Status_txt = findViewById(R.id.Status);
        float Height = Float.parseFloat(In_height.getText().toString())/100;
        float Weight = Float.parseFloat(In_weight.getText().toString());
        float bmiValue = (float) (Weight / (Height * Height));
        String resultBmi = String.format("%.2f", bmiValue);
        BMI_txt.setText("BMI = "+resultBmi);
        if (bmiValue < 18.5) {
            Status_txt.setText(R.string.underweight);
            Status_txt.setTextColor(getColor(R.color.normal));
        } else if (bmiValue < 25) {
            Status_txt.setText(R.string.normal);
            Status_txt.setTextColor(getColor(R.color.normal));
        } else if (bmiValue < 30) {
            Status_txt.setTextColor(getColor(R.color.normal));
            Status_txt.setText(R.string.overweight);
        } else {
            Status_txt.setText(R.string.obese);
        }


    }
}